// WelcomePage.js
import React from "react";
import { Welcome } from "../components/Onboarding/Welcome";

export const WelcomePage = () => {
  return (
    <div>
      <Welcome />
    </div>
  );
};
