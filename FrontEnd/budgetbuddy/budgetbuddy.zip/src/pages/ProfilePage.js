export const ProfilePage = () => {
  return (
    <div>
      <h1>Support Page</h1>
    </div>
  );
}