export const SupportPage = () => {
  return (
    <div>
      <h1>Support Page</h1>
    </div>
  );
}