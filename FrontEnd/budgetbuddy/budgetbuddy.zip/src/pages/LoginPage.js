import React from "react";
import Login from "../components/SignIn/Login";

const LoginPage = () => {
  return <Login />;
};

export default LoginPage;
