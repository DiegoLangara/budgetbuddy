import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "bootstrap/dist/css/bootstrap.min.css";
import { LoadingProvider } from "./contexts/LandingContext";
import LoadingScreen from "./components/Common/loadingScreen";

const rootElement = document.getElementById("root");
const root = ReactDOM.createRoot(rootElement);

root.render(
  <React.StrictMode>
    <LoadingProvider>
      <LoadingScreen />
      <h1>TEST---{process.env.API_HOST}</h1>
      <App />

    </LoadingProvider>
  </React.StrictMode>
);
